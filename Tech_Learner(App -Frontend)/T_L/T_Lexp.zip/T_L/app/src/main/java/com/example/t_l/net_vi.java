package com.example.t_l;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class net_vi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_net_vi);
    }
}