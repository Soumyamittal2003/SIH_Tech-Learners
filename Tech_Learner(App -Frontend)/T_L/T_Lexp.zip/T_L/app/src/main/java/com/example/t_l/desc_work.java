package com.example.t_l;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.CollationElementIterator;

public class desc_work extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_desc_work);

        final Button button = findViewById(R.id.button2);
        final Button button2 = findViewById(R.id.button3);
        final Button button3 = findViewById(R.id.button4);
        final Button button4 = findViewById(R.id.button5);




        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openonclick();
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                                          openonclick2();
                                      }

        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                        openonclick3();
                    }

        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                        openonclick4();
                    }

                }


        );}



    public void openonclick(){
        Intent intent = new Intent(this,net_engi.class);
        startActivity(intent);

    }
    public void openonclick2(){
        Intent intent = new Intent(this,and_dev.class);
        startActivity(intent);

    }
    public void openonclick3(){
        Intent intent = new Intent(this,and_dev.class);
        startActivity(intent);

    }
    public void openonclick4(){
        Intent intent = new Intent(this,and_dev.class);
        startActivity(intent);

    }
};