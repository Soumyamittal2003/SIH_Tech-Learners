package com.example.t_l;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class anddeve_test extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anddeve_test);
    }
}