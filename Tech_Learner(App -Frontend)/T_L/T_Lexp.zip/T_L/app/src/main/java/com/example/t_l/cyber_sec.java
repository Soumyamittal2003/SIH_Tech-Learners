package com.example.t_l;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class cyber_sec extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cyber_sec);

        final Button button = findViewById(R.id.button7);
        final Button button1 = findViewById(R.id.button3);
        final Button button2 = findViewById(R.id.button8);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openonclick();
            }
            });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openonclick1();
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openonclick2();
            }
        });


}
    public void openonclick(){
        Intent intent = new Intent(this,experince.class);
        startActivity(intent);

    }
    public void openonclick1(){
        Intent intent = new Intent(this,experince.class);
        startActivity(intent);

    }
    public void openonclick2(){
        Intent intent = new Intent(this,experince.class);
        startActivity(intent);

    }}
